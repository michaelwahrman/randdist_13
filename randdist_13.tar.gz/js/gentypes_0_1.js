"use strict;"




// 
// test object generation
//

function gen_type1() {

    Speak("gen_type1");

    var num_pts = 128;
    var num_rings = 5;
    var num_spirals = 7;
    var d_angle = (2.0 * Math.PI) / (num_spirals);
    var s_radius = 0.7, e_radius = 0.1;
    var s_z = -0.25, e_z = 3.0;
    var i;

    for (i = 0; i < num_spirals; i++) {
      // gen_spiral(s_z, e_z, s_radius, e_radius, 0.045, 0.025, i * d_angle, (Math.PI*4.0) + (i*d_angle), 200, 1);
    }

    var d_radius = (e_radius - s_radius) / (num_rings - 1);
    var d_z = (e_z - s_z) / (num_rings - 1);

    for (i = 0; i < num_rings; i++) {
      var cur_z = s_z + (i * d_z);
      var cur_radius = s_radius + (i * d_radius);
      // gen_circle( cur_z, cur_radius, 128, 0.015, 2 );
    }
    gen_sphere( 0, 0, 1, 2.0, 25, 25, 0.1, 3 );
}


function gen_type2() {

    Speak("gen_type2");

    var num_pts = 128;
    var num_rings = 60;
    var num_spirals = 7;
    // var d_angle = (2.0 * Math.PI) / (num_spirals);
    var s_angle = 0.0, e_angle = 2.0 * Math.PI;
    var radius = 0.75;
    var s_z = -0.5, e_z = 3.0;
    var i;


    for (i = 0; i < num_spirals; i++) {
      // gen_spiral(s_z, e_z, s_radius, e_radius, 0.045, 0.025, i * d_angle, (Math.PI*4.0) + (i*d_angle), 200, 1);
    }

    // var d_radius = (e_radius - s_radius) / (num_rings - 1);
    var d_angle = (e_angle - s_angle) / (num_rings - 1);
    var d_z = (e_z - s_z) / (num_rings - 1);

    for (i = 0; i < num_rings; i++) {
      var cur_z = s_z + (i * d_z);
      // var cur_radius = s_radius + (i * d_radius);
      var cur_angle = s_angle + (i * d_angle);
      var cur_radius = radius - (Math.sin(cur_angle) * 0.25);
      if (cur_angle > 0 && cur_angle < (Math.PI * 2.0)) {
        gen_circle_noise( cur_z, cur_radius, 256, 0.045, 3, 0.25, 8 );
      } else {
        gen_circle( cur_z, cur_radius, 128, 0.025, 2 );
      }
    }
    // gen_sphere( 0, 0, 1, 2.0, 25, 25, 0.25, 3 );
}



function gen_type3() {

    Speak("gen_type3");

    var num_pts = 128;
    var num_rings = 120;
    var s_angle = 0.0, e_angle = 2.0 * Math.PI;
    var radius = 1.25;
    var s_z = -0.5, e_z = 5.0;
    var i;

    var d_angle = (e_angle - s_angle) / (num_rings - 1);
    var d_z = (e_z - s_z) / (num_rings - 1);

    for (i = 0; i < num_rings; i++) {
      var cur_z = s_z + (i * d_z);
      var cur_angle = s_angle + (i * d_angle);
      var cur_radius = radius // + (Math.sin(cur_angle) * 0.25);
      gen_circle_with_xydisp( global_image_1, cur_z, i, num_rings, 0.25, 0.75, 
		    cur_radius, num_pts, 0.05, 
		    Math.PI*0.5, Math.PI*1.5, Math.PI*2.0, 
		    0.1, 2 );
    }
    global_image_1.rpt_hist(); 
}




function gen_type4() {

    Speak("gen_type4");

    var num_pts = 128;
    var num_rings = 200;
    var s_angle = 0.0, e_angle = 2.0 * Math.PI;
    var radius = 1.25;
    var emit_size = 0.05;
    var obj_num = 4;
    var s_z = -0.5, e_z = 3.0;
    var i, j, v, cur_phi;

    var base1 = makeBase("sph");
    var mod01 = makeModifier("sin", -0.25, 0.0, 2.0);
    var mod02 = makeModifier("cos", 0.15, Math.PI/2.0, 4.0);
    var layer1 = makeLayer("cyl type 4", base1, [mod01, mod02], radius, num_pts, num_rings);

    var base2 = makeBase("sph");
    var mod03 = makeModifier("sin", -0.25, 0.0, 2.0);
    var mod04 = makeModifier("cos", 0.5, Math.PI/2.0, 4.0);
    var layer2 = makeLayer("cyl type 4", base1, [mod03, mod04], radius, num_pts, num_rings);

    var layer3 = makeLayer("cyl type 4", base1, [], radius, num_pts, num_rings);



    var d_phi = (2.0 * Math.PI) / (num_pts - 1); 
    var d_theta = (2.0 * Math.PI) / (num_rings - 1);
    var d_z = (e_z - s_z) / (num_rings - 1);

    for (i = 0; i < num_rings; i++) {
      var cur_z = s_z + (i * d_z);
      var cur_theta = i * d_theta; 
      var cur_radius = radius; 
      for (j = 0; j < num_pts; j++) {
        cur_phi = j * d_phi;
        v = layer2.value( cur_radius, cur_phi, cur_theta, cur_z );
        var s = make_sphlist_item (v[0], v[1], v[2] * e_z, emit_size, obj_num);
        sphlist.push(s);
      }
    }
}



function gen_type5() {

    Speak("gen_type5");

    var num_pts = 64;
    var num_rings = 256;
    var s_angle = 0.0, e_angle = 2.0 * Math.PI;
    var radius = 1.25;
    var emit_size = 0.075;
    var obj_num = 4;
    var s_z = -0.5, e_z = 3.0;
    var i, j, v, cur_phi;

    var base1 = makeBase("sph");
    var mod01 = makeModifier("sin", -0.25, 0.0, 2.0);
    var mod02 = makeModifier("cos", 0.15, Math.PI/2.0, 4.0);
    var layer1 = makeLayer("cyl type 5", base1, [mod01, mod02], radius, num_pts, num_rings);

    var base2 = makeBase("sph");
    var mod03 = makeModifier("sin", -0.25, 0.0, 2.0);
    var mod04 = makeModifier("cos", 0.5, Math.PI/2.0, 4.0);
    var layer2 = makeLayer("cyl type 5", base1, [mod03, mod04], radius, num_pts, num_rings);

    var layer3 = makeLayer("cyl type 5", base1, [], radius, num_pts, num_rings);



    var d_phi = (2.0 * Math.PI) / (num_pts - 1); 
    var d_theta = (2.0 * Math.PI) / (num_rings - 1);
    var d_z = (e_z - s_z) / (num_rings - 1);

    obj_num = layer2.id(); 
    for (i = 0; i < num_rings; i++) {
      var cur_z = s_z + (i * d_z);
      var cur_theta = i * d_theta; 
      var cur_radius = radius; 
      for (j = 0; j < num_pts; j++) {
        cur_phi = j * d_phi;
        v = layer2.value( cur_radius, cur_phi, cur_theta, cur_z );
        var s = make_sphlist_item (v[0], v[1], v[2] * e_z, emit_size, obj_num);
        sphlist.push(s);
      }
    }
}


function gen_type6() {

    Speak("gen_type6");

    var num_pts = 128;
    var num_rings = 128;
    var s_angle = 0.0, e_angle = 2.0 * Math.PI;
    var radius = .5;
    var emit_size = 0.05;
    var s_z = -0.0, e_z = 2.0;
    var i, j, v, cur_phi, obj_num;

    var base1 = makeBase("sph");
    var mod01 = makeModifier("sin", -0.25, 0.0, 2.0);
    var mod02 = makeModifier("cos", 0.15, Math.PI/2.0, 4.0);
    var layer1 = makeLayer("sph type 5", base1, [mod01, mod02], [], radius, num_pts, num_rings);

    var base2 = makeBase("sph");
    var mod03 = makeModifier("sin", -0.25, 0.0, 2.0);
    var mod04 = makeModifier("cos", 0.5, Math.PI/2.0, 4.0);
    var layer2 = makeLayer("sph type 5", base1, [mod03, mod04], [], radius, num_pts, num_rings);

    var layer3 = makeLayer("sph type 5", base1, [], [], radius, num_pts, num_rings);

    var base3 = makeBase("plane");
    var mod05 = makeModifier("circle", 0.5, 0, 0);
    var layer4 = makeLayer("plane", base1, [mod03, mod05], [], radius, num_pts, num_rings);

    var d_phi = (2.0 * Math.PI) / (num_pts - 1); 
    var d_theta = (2.0 * Math.PI) / (num_rings - 1);
    var d_z = (e_z - s_z) / (num_rings - 1);

    obj_num = layer2.id(); 
    for (i = 0; i < num_rings; i++) {
      var cur_z = s_z + (i * d_z);
      var cur_theta = -Math.PI + (i * d_theta); 
      var cur_radius = radius; 
      for (j = 0; j < num_pts; j++) {
        cur_phi = -Math.PI + (j * d_phi);
        v = layer4.value( cur_radius, cur_phi, cur_theta, cur_z );
        var s = make_sphlist_item (v[0], v[1], v[2] * e_z, emit_size, obj_num);
        sphlist.push(s);
      }
    }
}

function gen_type7() {

    Speak("gen_type7");

    var num_pts = 128;
    var num_rings = 128;
    var s_angle = 0.0, e_angle = 2.0 * Math.PI;
    var radius = .5;
    var emit_size = 0.05;
    var s_z = -0.0, e_z = 2.0;
    var i, j, v, cur_phi, obj_num, pt;

    var base1 = makeBase("cyl", 1, 1, 2);
    var mod01 = makeModifier("sin", -0.25, 0.0, 0.5);
    var mod02 = makeModifier("cos",  0.25, 3.14, 4);
    var mod06 = makeModifier("line", 0.025, 0, 0, Math.PI/2.0, Math.PI/64);
    var appendage1 = makeAppendage("sphere", 0.25, Math.PI, Math.PI, Math.PI/64.0);
    var appendage2 = makeAppendage("ring", 2.0, Math.PI/4.0, - Math.PI/16.0, Math.PI/64.0, true, 128, 128); 
    var layer1 = makeLayer("l1", base1, [mod01, mod02], [appendage2], radius, num_pts, num_rings);

    var d_phi = (2.0 * Math.PI) / (num_pts - 1); 
    var d_theta = (2.0 * Math.PI) / (num_rings - 1);
    var d_z = (e_z - s_z) / (num_rings - 1);

    obj_num = layer1.id(); 
    for (i = 0; i < num_rings; i++) {
      var cur_z = s_z + (i * d_z);
      var cur_theta = -Math.PI + (i * d_theta); 
      var cur_radius = radius; 
      for (j = 0; j < num_pts; j++) {
        cur_phi = -Math.PI + (j * d_phi);
        v = layer1.value( cur_radius, cur_phi, cur_theta, cur_z );
        var s = make_sphlist_item (v[0], v[1], v[2], emit_size, obj_num);
        sphlist.push(s);
      }
    }

    var a_list = layer1.get_sphlists();
    console.log("a_list length = " + a_list.length.toString());
    for (i = 0; i < a_list.length; i++) {
      var l = a_list[i];
      // console.log(l.length);
      for (j = 0; j < l.length; j++) {
        pt = l[j];
        s = make_sphlist_item(pt[0], pt[1], pt[2], emit_size, obj_num);
        sphlist.push(s);
      }
    }
}


function gen_type8() {

    Speak("gen_type8");

    var num_pts = 128;
    var num_rings = 128;
    var s_angle = 0.0, e_angle = 2.0 * Math.PI;
    var radius = 0.75;
    var emit_size = 0.05;
    var s_z = -0.0, e_z = 2.0;
    var i, j, v, cur_phi, obj_num, pt;

    var base1 = makeBase("cyl", 1, 1, 2);
    var mod01 = makeModifier("sin", -0.25, 0.0, 0.5);
    var mod02 = makeModifier("cos",  0.25, 3.14, 4);
    var mod06 = makeModifier("line", 0.025, 0, 0, Math.PI/2.0, Math.PI/64);
    var mod07 = makeModifier("spiral", 1.0, Math.PI, 1.0); 
    var appendage1 = makeAppendage("sphere", 0.25, Math.PI, Math.PI, Math.PI/64.0);
    var appendage2 = makeAppendage("ring", 2.0, Math.PI/4.0, - Math.PI/16.0, Math.PI/64.0, true, 128, 128); 
    var layer1 = makeLayer("l1", base1, [mod01, mod07], [], radius, num_pts, num_rings);

    var d_phi = (2.0 * Math.PI) / (num_pts - 1); 
    var d_theta = (2.0 * Math.PI) / (num_rings - 1);
    var d_z = (e_z - s_z) / (num_rings - 1);

    obj_num = layer1.id(); 
    for (i = 0; i < num_rings; i++) {
      var cur_z = s_z + (i * d_z);
      var cur_theta = -Math.PI + (i * d_theta); 
      var cur_radius = radius; 
      for (j = 0; j < num_pts; j++) {
        cur_phi = -Math.PI + (j * d_phi);
        v = layer1.value( cur_radius, cur_phi, cur_theta, cur_z );
        var s = make_sphlist_item (v[0], v[1], v[2], emit_size, obj_num);
        sphlist.push(s);
      }
    }

    var a_list = layer1.get_sphlists();
    console.log("a_list length = " + a_list.length.toString());
    for (i = 0; i < a_list.length; i++) {
      var l = a_list[i];
      // console.log(l.length);
      for (j = 0; j < l.length; j++) {
        pt = l[j];
        s = make_sphlist_item(pt[0], pt[1], pt[2], emit_size, obj_num);
        sphlist.push(s);
      }
    }
}
