"use strict"; 

var l_object_unique_number 

var makeLayer = function(name, base, modlist, applist, radius, pts_per_ring, num_rings) {

  var l_name = name;
  var l_id = Date.now(); 
  var l_radius = radius;
  var l_ppr = pts_per_ring;
  var l_numrings = num_rings;
  var l_radians_per_point = Math.PI / l_ppr;
  var l_radians_per_ring = (2*Math.PI) / l_numrings; 
  var l_phi = null, l_theta = null; 
  var l_base = base;
  var l_modifiers = modlist;
  var l_appendages = applist;
  var l_sphlist = []; 

// angles are in radians, 0 >= phi < pi, 0 >= theta <= 2pi

  console.log("makeLayer " + name + " created with id = " + l_id);

  return {
  
    get_sphlists: function() {
      return (l_sphlist);
    },

    id: function() {
      return l_id;
    },

    name: function() {
      return l_name;
    }, 

    process_appendages: function(phi, theta, xyz) {
      var i;
      var a;

      for (i = 0; i < l_appendages.length; i++) {
        a = l_appendages[i]; 
        l_sphlist.push(a.generate(theta, phi, xyz));
      }
    }, 

    value: function(radius, phi, theta, z) {
      var sr = 0; 
      var m, i, a, result; 
      
      // l_sphlist = []; 
      for (i = 0; i < l_modifiers.length; i++) {
        m = l_modifiers[i];
        sr += m.value(radius, phi, theta); 
      }
      var v = l_base.value(radius + sr, phi, theta, z);
      for (i = 0; i < l_appendages.length; i++) {
        a = l_appendages[i];
        result = a.generate(theta, phi, v);
        if (result.length > 0) {
          l_sphlist.push(result);
        }
      }
      // console.log(l_sphlist.length);
      return v;
    } 

  };
};

console.log("makeLayer defined");


// sx, sy, sz is scale xyz
// tx, ty, tz is translate xyz

var makeBase = function(operation, sx=1, sy=1, sz=1, tx=0, ty=0, tz=0) {

  var b_operation = operation;
  var b_sx = sx;
  var b_sy = sy;
  var b_sz = sz;
  var b_tx = tx, b_ty = ty, b_tz = tz;

  console.log("makeBase " + operation); 

  return {
  
    value: function(radius, phi, theta, z) {
      let x, y, myz, v;

      if (b_operation == "cyl" || b_operation == "cylinder") { 

	x = radius * Math.cos(phi);
        y = radius * Math.sin(phi);
        v = [b_tx+(x*b_sx), b_ty+(y*b_sy), b_tz+(z*b_sz)];

      } else if (b_operation == "sph" || b_operation == "sphere") {
        
        x = radius * Math.sin(theta) * Math.cos(phi);
        y = radius * Math.sin(theta) * Math.sin(phi);
        myz = radius * Math.cos(theta);
        v = [b_tx+(x*b_sx), b_ty+(y*b_sy), b_tz+(myz*b_sz)];

      } else if (b_operation == "plane") {

        // x = radius * ((phi - Math.PI)/Math.PI);
        // y = radius * ((theta - Math.PI)/Math.PI);
        x = radius * ((phi-Math.PI) / (2.0*Math.PI));
        y = radius * ((theta-Math.PI) / (2.0*Math.PI));
        v = [b_tx+(x*b_sx), b_ty+(y*b_sy), b_tz+(z*b_sz)];

      } else {
        console.log("unknown operation for base: " + b_operation);
        v = [0, 0, z]; 
      }
      return v;
    }       

  };
};

console.log("makeBase defined");


var makeModifier = function(operation, amplitude=1, offset=0, scale=1, center=0.0, tolerance=(2.0*Math.PI)/64.0) {

  var m_operation = operation;
  var m_amplitude = amplitude; 
  var m_offset = offset;
  var m_center = center;
  var m_tolerance = tolerance;

  var m_spiral = function(a, b, angle) {
    var r = a + (b * angle); 
    return (r);
  }

  var m_spiral_2d = function(a, b, angle) {
    var r = m_spiral(a, b, angle);
    var x = r * Math.cos(angle);
    var y = r * Math.sin(angle);
    return( [x, y] );
  }

  console.log("makeModifier " + operation + " amp = " + amplitude + " offset = " + offset + " scale = " + scale);

  return {
  
    value: function(radius, phi, theta) {
      let v = 0;

      if (m_operation == "sin") { 

        v = Math.sin((theta*scale)+offset) * amplitude;

      } else if (m_operation == "cos") {

        v = Math.cos((theta*scale)+offset) * amplitude;

      } else if (m_operation == "noise") {

        let myturb = turb(8, phi, theta, radius) * amplitude;
        v = myturb;

      } else if (m_operation == "circle") {

        let mx = phi / (2.0*Math.PI);
        let my = theta / (2.0*Math.PI);
        let mr = Math.sqrt(mx*mx + my*my);
        if (Math.abs(radius-mr) < 0.05) {
          v = amplitude;
        }

      } else if (m_operation == "line") {

        if (Math.abs((theta*scale)+offset - m_center) <= m_tolerance) {
          v = amplitude;
        }

      } else if (m_operation == "spiral") {

        v = m_spiral(0, radius, (phi*scale)+offset) * amplitude; 

      } else if (m_operation == "null") {

        v = 0;

      } else {
        console.log("unknown operation for modifier: " + m_operation);
        v = 0; 
      }
      return v;
    }       

  };
};

console.log("makeModifier defined");


var makeAppendage = function(operation, radius, phi_center, theta_center, tolerance, center=false, num_theta=64, num_phi=64) {

  var a_operation = operation;
  var a_radius = radius;
  var a_phi_center = phi_center;
  var a_theta_center = theta_center;
  var a_tolerance = tolerance;
  var a_num_theta = num_theta;
  var a_num_phi = num_phi; 
  var a_center = center;
  // var a_d_phi = d_phi;
  // var a_d_theta = d_theta;

  var get_circle_xy = function(a, b, r, angle ) {
    
    var x = a + (r * Math.cos(angle));
    var y = b + (r * Math.sin(angle));
    
    return( [x, y] );
  };

  var get_sphere_xyz = function(radius, theta, phi) {

        var x = r * Math.sin(theta) * Math.cos(phi);
        var y = r * Math.sin(theta) * Math.sin(phi);
        var z = r * Math.cos(theta);

        return( [x, y, z] );
  }; 

  var make_geometry = function(radius, num_phi, num_theta, ixyz) {
      let v = 0;
      let a_list = [];
      let d_theta, d_phi, pxyz, xyz, i, j, xy; 

      if (a_operation == "sphere") { 

        d_theta = Math.PI / (num_theta-1); 
        d_phi = (2 * Math.PI) / (num_phi-1);
        for (i=0; i < num_theta; i++) {
          for (j=0; j < num_phi; j++) {
            xyz = self.get_sphere_xyz(radius, i*d_theta, j*d_phi);
            a_list.push([xyz[0]+ixyz[0], xyz[1]+ixyz[1], xyz[2]+ixyz[2]]);
          }
        }
      } else if (a_operation == "ring") {

        d_phi = (2.0 * Math.PI) / (num_phi-1);
	for (i = 0; i < num_phi; i++) {
          xy = get_circle_xy(0, 0, radius, i * d_phi); 
          xyz = [xy[0], xy[1], 0]; 
          a_list.push([xyz[0]+ixyz[0], xyz[1]+ixyz[1], xyz[2]+ixyz[2]]);
        }

      } else {
        console.log("unknown operation for modifier: " + a_operation);
      }
      return a_list;
    };   

  console.log("makeAppendage " + operation + " radius = " + radius + " phi_center = " + phi_center + " theta_center = " + theta_center);

  return {

    generate: function(theta, phi, ixyz) {
      if (Math.abs(theta-a_theta_center) <= a_tolerance && Math.abs(phi-a_phi_center) <= a_tolerance) {
        console.log("appendage hit");
        if (a_center == true) {
          return(make_geometry(a_radius, a_num_phi, a_num_theta, [0,0,ixyz[2]]));
        } else {
          return( make_geometry(a_radius, a_num_phi, a_num_theta, ixyz) );
        }
      }
      else {
        return( [] );
      }
    }

  };
};

console.log("makeAppendage defined");


